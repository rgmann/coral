#include "AssemblyEndMarker.h"

//------------------------------------------------------------------------------
AssemblyEndMarker::AssemblyEndMarker()
: RsyncAssemblyInstr(RsyncAssemblyInstr::EndMarkerType, 0)
{
}

//------------------------------------------------------------------------------
//ui32 AssemblyEndMarker::dataSize() const
//{
//   return 0;
//}

#include <stdio.h>
#include "RsyncSegmentReportPacket.h"

//------------------------------------------------------------------------------
RsyncSegmentReportPacket
::RsyncSegmentReportPacket()
: RsyncPacket(SegmentReportType, sizeof(Data))
{
}

//------------------------------------------------------------------------------
RsyncSegmentReportPacket
::RsyncSegmentReportPacket(Type type, ui32 nDataSize)
: RsyncPacket(SegmentReportType, sizeof(Data) + nDataSize)
{
   if (isAllocated())
   {
      data()->type = type;
      data()->length = nDataSize;
   }
}

//------------------------------------------------------------------------------
RsyncSegmentReportPacket::Type RsyncSegmentReportPacket::type() const
{
   Type type = TypeNotSet;
   printf("RsyncSegmentReportPacket::type\n");
   if (isAllocated())
   {
      type = (Type)data()->type;
   }
   
   return type;
}

//------------------------------------------------------------------------------
//void* RsyncSegmentReportPacket::dataPtr()
//{
//   printf("RsyncSegmentReportPacket::dataPtr\n");
//   return inherited::dataEndPtr();
//}

//------------------------------------------------------------------------------
//void* const RsyncSegmentReportPacket::dataPtr() const
//{
//   printf("RsyncSegmentReportPacket::dataPtr\n");
//   return inherited::dataEndPtr();
//}

//------------------------------------------------------------------------------
//void* RsyncSegmentReportPacket::dataEndPtr()
//{
//   printf("RsyncSegmentReportPacket::dataEndPtr\n");
//   if (isAllocated())
//   {
//      ui8* l_pData = reinterpret_cast<ui8*>(dataPtr());
//      return reinterpret_cast<void*>(l_pData + dataSize());
//   }
//   
//   return NULL;
//}

//------------------------------------------------------------------------------
//void* const RsyncSegmentReportPacket::dataEndPtr() const
//{
//   printf("RsyncSegmentReportPacket::dataEndPtr\n");
//   if (isAllocated())
//   {
//      ui8* const l_pData = reinterpret_cast<ui8* const>(dataPtr());
//      return reinterpret_cast<void* const>(l_pData + dataSize());
//   }
//   
//   return NULL;
//}

//------------------------------------------------------------------------------
ui32 RsyncSegmentReportPacket::dataSize() const
{
   return sizeof(Data);
}

//------------------------------------------------------------------------------
ui32 RsyncSegmentReportPacket::dataOffset() const
{
   printf("RsyncSegmentReportPacket::dataOffset\n");
   return inherited::inclusiveSize();
}

//------------------------------------------------------------------------------
ui32 RsyncSegmentReportPacket::inclusiveSize() const
{
   return inherited::inclusiveSize() + dataSize();
}

//------------------------------------------------------------------------------
RsyncSegmentReportPacket::Data* RsyncSegmentReportPacket::data()
{
   return reinterpret_cast<Data*>(dataPtr());
}

//------------------------------------------------------------------------------
RsyncSegmentReportPacket::Data* const RsyncSegmentReportPacket::data() const
{
   return reinterpret_cast<Data* const>(dataPtr());
}

//------------------------------------------------------------------------------
bool RsyncSegmentReportPacket::unpack(const void* pPkt, ui32 nSizeBytes)
{
   bool  l_bRecognized = false;
   
   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("inherited::unpack: failed\n");
      return false;
   }
   
   // Check that the size is at least large enough for the RsyncPacket's
   // inclusive size.
   if (nSizeBytes < inclusiveSize())
   {
      printf("::unpack: too small\n");
      return false;
   }
   
   // Validate the packet type field.
   switch (type())
   {
      case HeaderType:
      case SegmentType:
         l_bRecognized = true;
         break;
         
      default:
         l_bRecognized = true;
         break;
   }
   
   if (!l_bRecognized)
   {
      printf("::unpack: ungrecognized packet ID\n");
      return false;
   }
   
   // Validate the size of the packet against the indicated payload size.
   if ((nSizeBytes - inclusiveSize()) != data()->length)
   {
      printf("::unpack: size mismatch - size = %u, exp = %u\n",
             (nSizeBytes - inclusiveSize()), data()->length);
      return false;
   }
   
   return true;
}

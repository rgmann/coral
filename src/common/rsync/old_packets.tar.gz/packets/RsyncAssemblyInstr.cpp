#include "RsyncAssemblyInstr.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

//------------------------------------------------------------------------------
RsyncAssemblyInstr::RsyncAssemblyInstr()
: RsyncPacket(RsyncPacket::AssemblyInstType, sizeof(RsyncAssemblyInstr::Data))
{
   if (isAllocated())
   {
      data()->type = TypeNotSet;
   }
}

//------------------------------------------------------------------------------
RsyncAssemblyInstr::RsyncAssemblyInstr(Type type, ui32 nSizeBytes)
: RsyncPacket(RsyncPacket::AssemblyInstType,
              sizeof(RsyncAssemblyInstr::Data) + nSizeBytes)
{
   if (isAllocated())
   {
      data()->type   = type;
      data()->length = nSizeBytes;
      printf("RsyncAssemblyInstr: ttl=%u, payload size=%u\n",
             allocatedSize(), nSizeBytes);
   }
}

//------------------------------------------------------------------------------
RsyncAssemblyInstr::~RsyncAssemblyInstr()
{
   destroy();
}

//------------------------------------------------------------------------------
RsyncAssemblyInstr::Type RsyncAssemblyInstr::type() const
{
   Type type = TypeNotSet;
   
   if (isAllocated())
   {
      type = (Type)data()->type;
   }
   
   return type;
}

//------------------------------------------------------------------------------
RsyncAssemblyInstr::Data* const RsyncAssemblyInstr::data() const
{
   if (isAllocated())
   {
      Data* const l_pData = reinterpret_cast<Data* const>(dataPtr());
      return l_pData;
   }
   
   return NULL;
}

//------------------------------------------------------------------------------
ui32 RsyncAssemblyInstr::dataSize() const
{
   return sizeof(Data);
}

//------------------------------------------------------------------------------
ui32 RsyncAssemblyInstr::dataOffset() const
{
   return inherited::inclusiveSize();
}

//------------------------------------------------------------------------------
ui32 RsyncAssemblyInstr::inclusiveSize() const
{
   return dataOffset() + dataSize();
}

//------------------------------------------------------------------------------
bool RsyncAssemblyInstr::unpack(const void* pPkt, ui32 nSizeBytes)
{
   bool l_bRecognized = false;

   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("RsyncAssemblyInstr::unpack: inherited unpack failed.\n");
      return false;
   }
   
   // Verify that the packet is at least large enough to contain the
   // RsyncAssemblyInstr data segment and all preceding data segments.
   if (nSizeBytes < inclusiveSize())
   {
      printf("::unpack: too small\n");
      return false;
   }
   
   // Validate the packet type.
   switch (type())
   {
      case BeginMarkerType:
      case EndMarkerType:
      case ChunkType:
      case SegmentType:
         l_bRecognized = true;
         break;
         
      default:
         l_bRecognized = false;
         break;
   }
   
   if (!l_bRecognized)
   {
      printf("::unpack: ungrecognized packet ID\n");
      return false;
   }
      
   // Validate the size of the packet against the indicated payload size.
   if ((nSizeBytes - inclusiveSize()) != data()->length)
   {
      printf("::unpack: size mismatch - size = %u, exp = %u\n",
             (nSizeBytes - inclusiveSize()), data()->length);
      return false;
   }
   
   return true;
}

//------------------------------------------------------------------------------
void* RsyncAssemblyInstr::dataPtr()
{
   return inherited::dataEndPtr();
}

//------------------------------------------------------------------------------
void* const RsyncAssemblyInstr::dataPtr() const
{
   return inherited::dataEndPtr();
}

//------------------------------------------------------------------------------
void* RsyncAssemblyInstr::dataEndPtr()
{
   if (dataPtr())
   {
      ui8* l_pData = reinterpret_cast<ui8*>(dataPtr());
      return reinterpret_cast<void*>(l_pData + dataSize());
   }
   
   return NULL;
}

//------------------------------------------------------------------------------
void* const RsyncAssemblyInstr::dataEndPtr() const
{
   if (dataPtr())
   {
      ui8* const l_pData = reinterpret_cast<ui8* const>(dataPtr());
      return reinterpret_cast<void* const>(l_pData + dataSize());
   }
   
   return NULL;
}

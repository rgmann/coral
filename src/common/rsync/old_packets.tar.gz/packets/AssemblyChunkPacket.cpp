#include "AssemblyChunkPacket.h"

//------------------------------------------------------------------------------
AssemblyChunkPacket::AssemblyChunkPacket()
: RsyncAssemblyInstr(RsyncAssemblyInstr::ChunkType, 0)
{
   if (isAllocated())
   {
      inherited::data()->length = 0;
   }
}

//------------------------------------------------------------------------------
AssemblyChunkPacket::AssemblyChunkPacket(ui32 nChunkSizeBytes)
 : RsyncAssemblyInstr(RsyncAssemblyInstr::ChunkType, nChunkSizeBytes)
{
   if (isAllocated())
   {
      inherited::data()->length = nChunkSizeBytes;
   }
}

//------------------------------------------------------------------------------
ui32 AssemblyChunkPacket::dataSize() const
{
   ui32 l_nDataSize = 0;
   
   if (isAllocated())
   {
      l_nDataSize = inherited::data()->length;
   }
   
   return l_nDataSize;
}

//------------------------------------------------------------------------------
char* const AssemblyChunkPacket::data()
{
   return reinterpret_cast<char* const>(dataEndPtr());
}

//------------------------------------------------------------------------------
bool AssemblyChunkPacket::unpack(const void* pPkt, ui32 nSizeBytes)
{
   ui32 l_nChunkSize = 0;
   
   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("RsyncAssemblyInstr::unpack: inherited unpack failed.\n");
      return false;
   }
   
   l_nChunkSize = inherited::data()->length;
   
   // Verify that the indicated packet size is the same as the
   // actual packet size.
   if (l_nChunkSize != (allocatedSize() - dataOffset()))
   {
      printf("AssemblyChunkPacket::unpack: incorrect size\n");
      return false;
   }
   
   return true;
}

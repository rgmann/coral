#include "AssemblySegmentPacket.h"

//------------------------------------------------------------------------------
AssemblySegmentPacket::AssemblySegmentPacket()
: RsyncAssemblyInstr(RsyncAssemblyInstr::SegmentType,
                     sizeof(AssemblySegmentPacket::Data))
{
   if (isAllocated())
   {
      setSegmentId(0);
   }
}

//------------------------------------------------------------------------------
AssemblySegmentPacket::AssemblySegmentPacket(ui32 nSegmentId)
: RsyncAssemblyInstr(RsyncAssemblyInstr::SegmentType,
                     sizeof(AssemblySegmentPacket::Data))
{
   if (isAllocated())
   {
      setSegmentId(nSegmentId);
   }
}

//------------------------------------------------------------------------------
void AssemblySegmentPacket::setSegmentId(ui32 nSegmentId)
{
   if (isAllocated())
   {
      data()->segmentId = nSegmentId;
   }
}

//------------------------------------------------------------------------------
ui32 AssemblySegmentPacket::getSegmentId() const
{
   if (isAllocated())
   {
      return data()->segmentId;
   }
   
   return 0;
}

//------------------------------------------------------------------------------
ui32 AssemblySegmentPacket::dataOffset() const
{
   return inherited::inclusiveSize();
}

//------------------------------------------------------------------------------
AssemblySegmentPacket::Data* const AssemblySegmentPacket::data() const
{
   return reinterpret_cast<Data* const>(inherited::dataEndPtr());
}

//------------------------------------------------------------------------------
bool AssemblySegmentPacket::unpack(const void* pPkt, ui32 nSizeBytes)
{
   ui32 l_nDataSize = 0;
   
   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("AssemblySegmentPacket::unpack: inherited unpack failed.\n");
      return false;
   }
   
   l_nDataSize = inherited::data()->length;
   
   // Verify that the indicated packet size is the same as the
   // actual packet size.
   if (l_nDataSize != (allocatedSize() - dataOffset()))
   {
      printf("AssemblySegmentPacket::unpack: incorrect size\n");
      return false;
   }
   
   return true;
}

#include <string.h>
#include <stdio.h>
#include "RsyncPacket.h"

//------------------------------------------------------------------------------
RsyncPacket::RsyncPacket()
: GenericPacket(sizeof(RsyncPacket::Data))
{
}

//------------------------------------------------------------------------------
RsyncPacket::RsyncPacket(Type type, ui32 nDataSize)
: GenericPacket(sizeof(RsyncPacket::Data) + nDataSize)
{
   if (allocate())
   {
      data()->marker = RsyncPacketMarker;
      data()->type   = type;
      data()->length = nDataSize;
   }
}

//------------------------------------------------------------------------------
RsyncPacket::Type RsyncPacket::type() const
{
   Type type = TypeNotSet;
   printf("RsyncPacket::type\n");
   if (isAllocated())
   {
      type = (Type)data()->type;
   }
   
   return type;
}

//------------------------------------------------------------------------------
RsyncPacket::Data* const RsyncPacket::data() const
{
   printf("RsyncPacket::data\n");
   return reinterpret_cast<Data* const>(dataPtr());
}

//------------------------------------------------------------------------------
ui32 RsyncPacket::dataSize() const
{
   return sizeof(Data);
}

//------------------------------------------------------------------------------
ui32 RsyncPacket::dataOffset() const
{
   printf("RsyncPacket::dataOffset\n");
   return inherited::inclusiveSize();
}

//------------------------------------------------------------------------------
ui32 RsyncPacket::inclusiveSize() const
{
   return inherited::inclusiveSize() + dataSize();
}

//------------------------------------------------------------------------------
bool RsyncPacket::unpack(const void* pPkt, ui32 nSizeBytes)
{
   bool  l_bRecognized = false;
   
   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("inherited::unpack: failed\n");
      return false;
   }
   
   // Check that the size is at least large enough for the RsyncPacket's
   // inclusive size.
   if (nSizeBytes < inclusiveSize())
   {
      printf("::unpack: too small\n");
      return false;
   }
   
   // Validate the marker
   if (data()->marker != RsyncPacketMarker)
   {
      printf("::unpack: bad marker\n");
      return false;
   }
   
   // Validate the packet type field.
   switch (type())
   {
      case SegmentReportType:
      case AssemblyInstType:
         l_bRecognized = true;
         break;
         
      default:
         l_bRecognized = true;
         break;
   }
   
   if (!l_bRecognized)
   {
      printf("::unpack: ungrecognized packet ID\n");
      return false;
   }
   
   // Validate the size of the packet against the indicated payload size.
   if ((nSizeBytes - inclusiveSize()) != data()->length)
   {
      printf("::unpack: size mismatch - size = %u, exp = %u\n",
             (nSizeBytes - inclusiveSize()), data()->length);
      return false;
   }
   
   return true;
}

//------------------------------------------------------------------------------
//void* RsyncPacket::dataEndPtr()
//{
//   printf("RsyncPacket::dataEndPtr\n");
//   if (isAllocated())
//   {
//      ui8* l_pData = reinterpret_cast<ui8*>(dataPtr());
//      return reinterpret_cast<void*>(l_pData + dataSize());
//   }
//   
//   return NULL;
//}

//------------------------------------------------------------------------------
//void* const RsyncPacket::dataEndPtr() const
//{
//   printf("RsyncPacket::dataEndPtr\n");
//   if (isAllocated())
//   {
//      ui8* const l_pData = reinterpret_cast<ui8* const>(dataPtr());
//      return reinterpret_cast<void* const>(l_pData + dataSize());
//   }
//   
//   return NULL;
//}

#include "AssemblyBeginMarker.h"

//------------------------------------------------------------------------------
AssemblyBeginMarker::AssemblyBeginMarker(ui32 nPathStrLen)
: RsyncAssemblyInstr(RsyncAssemblyInstr::BeginMarkerType, sizeof(nPathStrLen))
{
}

//------------------------------------------------------------------------------
bool AssemblyBeginMarker::setPath(const std::string &filepath)
{
   bool l_bSuccess = false;
   
   if (isAllocated())
   {
      char* l_pCStr = reinterpret_cast<char*>(dataPtr());
      strncpy(l_pCStr, filepath.c_str(), dataSize());
      l_bSuccess = true;
   }
   
   return l_bSuccess;
}

//------------------------------------------------------------------------------
bool AssemblyBeginMarker::getPath(std::string &filepath)
{
   bool l_bSuccess = false;
   filepath = "";
   
   if (isAllocated())
   {
      char* l_pFilepath = reinterpret_cast<char*>(dataPtr());
      filepath = std::string(l_pFilepath);
      l_bSuccess = true;
   }
   
   return l_bSuccess;
}

//------------------------------------------------------------------------------
ui32 AssemblyBeginMarker::dataOffset() const
{
   return inherited::inclusiveSize();
}

//------------------------------------------------------------------------------
ui32 AssemblyBeginMarker::dataSize() const
{
   return allocatedSize() - dataOffset();
}

//------------------------------------------------------------------------------
ui32 AssemblyBeginMarker::inclusiveSize() const
{
   return dataOffset() + dataSize();
}

//------------------------------------------------------------------------------
void* AssemblyBeginMarker::dataPtr()
{
   return inherited::dataEndPtr();
}

//------------------------------------------------------------------------------
void* const AssemblyBeginMarker::dataPtr() const
{
   return inherited::dataEndPtr();
}

//------------------------------------------------------------------------------
void* AssemblyBeginMarker::dataEndPtr()
{
   if (isAllocated())
   {
      ui8* l_pData = reinterpret_cast<ui8*>(dataPtr());
      return reinterpret_cast<void*>(l_pData + dataSize());
   }
   
   return NULL;
}

//------------------------------------------------------------------------------
void* const AssemblyBeginMarker::dataEndPtr() const
{
   if (isAllocated())
   {
      ui8* const l_pData = reinterpret_cast<ui8* const>(dataPtr());
      return reinterpret_cast<void* const>(l_pData + dataSize());
   }
   
   return NULL;
}

//------------------------------------------------------------------------------
bool AssemblyBeginMarker::unpack(const void* pPkt, ui32 nSizeBytes)
{
   ui32 l_nDataSize = 0;
   
   if (!inherited::unpack(pPkt, nSizeBytes))
   {
      printf("AssemblyBeginMarker::unpack: inherited unpack failed.\n");
      return false;
   }
   
   l_nDataSize = inherited::data()->length;
   
   // Verify that the indicated packet size is the same as the
   // actual packet size.
   if (l_nDataSize != (inclusiveSize() - dataOffset()))
   {
      printf("AssemblyBeginMarker::unpack: incorrect size\n");
      return false;
   }
   
   return true;
}

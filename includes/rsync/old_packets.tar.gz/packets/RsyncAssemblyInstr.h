#ifndef RSYNC_ASSEMBLY_INSTR_H
#define RSYNC_ASSEMBLY_INSTR_H

#include "RsyncPacket.h"

//struct RsyncAssemblyInstrHdr
//{
//   static const unsigned int marker = 0x1B2CA5A3;
//   unsigned char type;
//   
//   union {
//      unsigned int segmentId;
//      unsigned int chunkSizeBytes;
//      unsigned int relPathLen;
//      unsigned int generic;
//   } info;
//};

class RsyncAssemblyInstr : public RsyncPacket
{
public:
   
   enum Type
   {
      TypeNotSet,
      BeginMarkerType,
      EndMarkerType,
      ChunkType,
      SegmentType
   };
   
   struct __attribute__((__packed__)) Data
   {
      ui32 type;
      ui32 length;
   };
   
   RsyncAssemblyInstr();
   
   /**
    * If type = RsyncChunkType, then nParam is treated as the chunk size
    * and used in allocating the data.
    *
    * If type = RsyncSegmentType, then nParam is treated as the segment ID
    * and the data pointer is NULL.
    */
   RsyncAssemblyInstr(Type type, ui32 nSizeBytes = 0);
   
   ~RsyncAssemblyInstr();
   
   Type type() const;
   
   Data* const data() const;
   
   virtual ui32 dataSize() const;
   
   virtual ui32 dataOffset() const;
   
   virtual ui32 inclusiveSize() const;
   
   bool  unpack(const void* pPkt, ui32 nSizeBytes);

protected:
   
   virtual void*       dataPtr();
   virtual void* const dataPtr() const;
   
   virtual void*       dataEndPtr();
   virtual void* const dataEndPtr() const;
   
private:
   
   typedef RsyncPacket inherited;
};

#endif // RSYNC_ASSEMBLY_INSTR_H
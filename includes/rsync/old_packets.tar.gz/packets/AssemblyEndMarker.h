#ifndef ASSEMBLY_END_MARKER_H
#define ASSEMBLY_END_MARKER_H

#include "RsyncAssemblyInstr.h"

class AssemblyEndMarker : public RsyncAssemblyInstr
{
public:
   
   enum Type
   {
   };
   
   struct __attribute__((__packed__)) Data
   {
   };
   
   AssemblyEndMarker();
   
   //bool  unpack(void* pPkt, unsigned int nSizeBytes);

private:

   typedef RsyncAssemblyInstr inherited;
};

#endif // ASSEMBLY_END_MARKER_H
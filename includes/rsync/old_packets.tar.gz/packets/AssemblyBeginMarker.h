#ifndef ASSEMBLY_BEGIN_MARKER_H
#define ASSEMBLY_BEGIN_MARKER_H

#include <string>
#include "RsyncAssemblyInstr.h"

class AssemblyBeginMarker : public RsyncAssemblyInstr
{
public:
   
   enum Type
   {
   };
   
   struct __attribute__((__packed__)) Data
   {
      // Filepath
   };
   
   /**
    * 
    */
   AssemblyBeginMarker(ui32 nPathStrLen);
   
   bool  setPath(const std::string &filepath);
   
   bool  getPath(std::string &filepath);
   
   bool  unpack(const void* pPkt, ui32 nSizeBytes);
   
protected:
   
   virtual ui32 dataSize() const;
   
   virtual ui32 dataOffset() const;
   
   virtual ui32 inclusiveSize() const;
   
   virtual void* dataPtr();
   virtual void* const dataPtr() const;
   
   virtual void* dataEndPtr();
   virtual void* const dataEndPtr() const;

private:

   typedef RsyncAssemblyInstr inherited;
};

#endif // ASSEMBLY_BEGIN_MARKER_H
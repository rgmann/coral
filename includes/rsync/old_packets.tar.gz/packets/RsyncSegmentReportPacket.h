#ifndef RSYNC_SEGMENT_REPORT_PACKET_H
#define RSYNC_SEGMENT_REPORT_PACKET_H

#include "RsyncPacket.h"


class RsyncSegmentReportPacket : public RsyncPacket
{
public:
   
   enum Type
   {
      TypeNotSet,
      HeaderType,
      SegmentType
   };
   
   struct __attribute__((__packed__)) Data
   {
      ui32  type;
      ui32  length;
   };
   
   RsyncSegmentReportPacket();
   
   RsyncSegmentReportPacket(Type type, ui32 nDataSize);
      
   virtual ui32 dataSize() const;
   
   virtual ui32 dataOffset() const;
   
   virtual ui32 inclusiveSize() const;
   
   Type type() const;
      
   virtual bool unpack(const void* pPkt, ui32 nSizeBytes);

protected:
   
//   virtual void* dataPtr();
//   virtual void* const dataPtr() const;
//   
//   virtual void* dataEndPtr();
//   virtual void* const dataEndPtr() const;
   
private:
   
   typedef RsyncPacket inherited;
   
   Data* data();

   Data* const data() const;
};

#endif // RSYNC_SEGMENT_REPORT_PACKET_H
#ifndef  RSYNC_PACKET_H
#define  RSYNC_PACKET_H

#include <stdio.h>
#include "GenericPacket.h"

//struct __attribute__((__packed__)) RsyncPacketHdr
//{
//   static const ui32  marker   = 0xFEEDBEEF;
//   ui32  type;
//   ui32  length;
//};

class RsyncPacket : public GenericPacket
{
public:
   
   enum Type
   {
      TypeNotSet,
      SegmentReportType,
      AssemblyInstType,
      NumTypes
   };
   
   struct __attribute__((__packed__)) Data
   {
      ui32  marker;
      ui32  type;
      ui32  length;
   };
   static const ui32 RsyncPacketMarker = 0xFEEDBEEF;
   
   RsyncPacket();
   
   RsyncPacket(Type type, ui32 nDataSize);
   
   Type type() const;
   
   bool length(ui32 &length) const;
   
   Data* const data() const;
   
   virtual ui32 dataSize() const;
   
   virtual ui32 dataOffset() const;
   
   virtual ui32 inclusiveSize() const;

   virtual bool unpack(const void* pPkt, ui32 nSizeBytes);

protected:
   
   // Not necessary to override the GenericPacket dataPtr() methods since
   // this packet implements the base type for all other packets and therefore
   // is at the beginning of the packet structure.
   
//   virtual void*        dataEndPtr();
//   virtual void* const  dataEndPtr() const;
   
private:
   
   typedef GenericPacket inherited;
};

#endif   // RSYNC_PACKET_H